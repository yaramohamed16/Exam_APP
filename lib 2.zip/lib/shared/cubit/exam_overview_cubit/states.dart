abstract class ExamsOverviewStats {}

class ExamsOverviewInitialStats extends ExamsOverviewStats {}

class ExamOverviewLoading extends ExamsOverviewStats {}

class ExamOverviewSuccess extends ExamsOverviewStats {}

class ExamOverviewError extends ExamsOverviewStats {}
