import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../models/exam_questions_model/exam_questions_model.dart';
import '../../../modules/exam_questions/exam_questions.dart';
import '../../cubit/exam_questions_cubit/exam_questions_cubit.dart';

void showQuestions(context, String mode) {
  showModalBottomSheet(
    context: context,
    builder: (BuildContext _) {
      return CustomBottomSheet(mode: mode);
    },
  );
}

class CustomBottomSheet extends StatefulWidget {
  const CustomBottomSheet({
    Key? key,
    required this.mode,
  }) : super(key: key);
  final String mode;
  @override
  _CustomBottomSheetState createState() => _CustomBottomSheetState();
}

class _CustomBottomSheetState extends State<CustomBottomSheet> {
  late ExamQuestionsCubit _examQuestionsCubit;
  Map<int, Data> _searchResultsMap = {};
  String _selectedFilter = 'All';

  @override
  void initState() {
    super.initState();
    _examQuestionsCubit = ExamQuestionsCubit();
  }

  @override
  void dispose() {
    _examQuestionsCubit.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider.value(
      value: _examQuestionsCubit..getExamQuestions(),
      child: _buildBottomSheetContent(),
    );
  }

  Widget _buildBottomSheetContent() {
    return Container(
      padding: const EdgeInsets.only(left: 24, right: 24, top: 24),
      decoration: const BoxDecoration(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20.0)),
        color: Colors.white,
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                "All Questions ",
                style: TextStyle(
                  fontSize: 16,
                  color: Color(0xff030712),
                  fontWeight: FontWeight.bold,
                ),
              ),
              IconButton(
                onPressed: () => Navigator.pop(context),
                icon: Image.asset('assets/images/close-circle.png'),
              )
            ],
          ),
          Container(
            height: 48,
            margin: const EdgeInsets.symmetric(vertical: 16),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    onChanged: (query) => _searchQuestions(query),
                    decoration: InputDecoration(
                      hintText: 'Search for question',
                      prefixIcon: Image.asset('assets/images/Search.png'),
                      contentPadding: const EdgeInsets.symmetric(
                          vertical: 10, horizontal: 16),
                      prefixIconColor: Color(0xff9CA3AF),
                      border: const OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(12)),
                        borderSide: BorderSide(color: Color(0xffE5E7EB)),
                      ),
                      enabledBorder: const OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(12)),
                        borderSide: BorderSide(color: Color(0xffE5E7EB)),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                PopupMenuButton<String>(
                  onSelected: (value) {
                    setState(() {
                      _selectedFilter = value;
                    });
                  },
                  itemBuilder: (BuildContext context) {
                    return ['All', 'Correct', 'Wrong'].map((String choice) {
                      return PopupMenuItem<String>(
                        value: choice,
                        child: Text(choice),
                      );
                    }).toList();
                  },
                  child: Container(
                    padding: EdgeInsets.all(8.0),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: Color(0xffE5E7EB),
                      ),
                    ),
                    child: Image.asset('assets/images/filter.png'),
                  ),
                ),
              ],
            ),
          ),
          BlocBuilder<ExamQuestionsCubit, ExamQuestionsState>(
            builder: (context, state) {
              if (state is ExamQuestionsSuccess) {
                return _buildQuestionList(widget.mode);
              } else if (state is ExamQuestionsLoading) {
                return Center(child: CircularProgressIndicator());
              } else {
                return Center(child: Text("Something went wrong"));
              }
            },
          ),
        ],
      ),
    );
  }

  Widget _buildQuestionList(String mode) {
    final filteredQuestions = _filterQuestions();
    return Expanded(
      child: ListView.separated(
        itemCount: filteredQuestions.length,
        padding: const EdgeInsets.only(bottom: 16),
        separatorBuilder: (BuildContext context, int index) => const Divider(),
        itemBuilder: (BuildContext context, int index) {
          return 'review' == mode
              ? ReviewQuestions(list: filteredQuestions, index: index)
              : Questions(list: filteredQuestions, index: index);
        },
      ),
    );
  }

  void _searchQuestions(String query) {
    setState(() {
      _searchResultsMap.clear();

      if (query.isNotEmpty && _examQuestionsCubit.model?.data != null) {
        _searchResultsMap = Map.fromEntries(
          _examQuestionsCubit.model!.data!.asMap().entries.where((entry) =>
              entry.value.title!.toLowerCase().contains(query.toLowerCase())),
        );
      }
    });
  }

  List<Data> _filterQuestions() {
    switch (_selectedFilter) {
      case 'Correct':
        return _filterResults('Correct');
      case 'Wrong':
        return _filterResults('Wrong');
      default:
        return _searchResultsMap.isNotEmpty
            ? _searchResultsMap.values.toList()
            : _examQuestionsCubit.model?.data ?? [];
    }
  }

  List<Data> _filterResults(String answerType) {
    return _searchResultsMap.isNotEmpty
        ? _searchResultsMap.values
            .where((question) =>
                question.studentAnswer != null &&
                question.studentAnswer == answerType)
            .toList()
        : _examQuestionsCubit.model?.data
                ?.where((question) =>
                    question.studentAnswer != null &&
                    question.studentAnswer == answerType)
                .toList() ??
            [];
  }
}

class ReviewQuestions extends StatelessWidget {
  const ReviewQuestions({
    super.key,
    required this.list,
    required this.index,
  });

  final List<Data>? list;
  final int index;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ExamQuestionsPage(
                index: 0,
                model: list![index],
                questionIndex: index,
              ),
            ));
      },
      child: SizedBox(
        height: 72,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 44,
              height: 34,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                color: const Color(0xffF3F4FF),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(list![index].id.toString(),
                      style: const TextStyle(color: Color(0xff0225FF))),
                  const Icon(
                    Icons.arrow_forward_ios_rounded,
                    size: 16,
                    color: Color(0xff0225FF),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Text(list![index].title!),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class Questions extends StatelessWidget {
  const Questions({
    super.key,
    required this.list,
    required this.index,
  });

  final List<Data>? list;
  final int index;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ExamQuestionsPage(
                index: 0,
                model: list![index],
                questionIndex: index,
              ),
            ));
      },
      child: SizedBox(
        height: 72,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 44,
              height: 34,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                color: const Color(0xffF3F4FF),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(list![index].id.toString(),
                      style: const TextStyle(color: Color(0xff0225FF))),
                  const Icon(
                    Icons.arrow_forward_ios_rounded,
                    size: 16,
                    color: Color(0xff0225FF),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Text(list![index].title!),
                  ),
                  Expanded(
                    child: Row(
                      children: [
                        Icon(
                          Icons.circle,
                          color:
                              list![index].studentAnswer.toString() == 'right'
                                  ? Colors.green
                                  : Colors.redAccent,
                          size: 8,
                        ),
                        const SizedBox(width: 5),
                        Text(list![index].studentAnswer.toString()),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
