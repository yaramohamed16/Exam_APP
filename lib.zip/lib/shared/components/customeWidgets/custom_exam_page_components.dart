//shared components

import 'package:flutter/material.dart';

import '../../../models/package_detail_model/details_model.dart';
import '../../../modules/exam_overview/exam_overview_page.dart';
import '../../cubit/package_details_cubit/cubit.dart';

import '../constants.dart';

class ExamListView extends StatelessWidget {
  const ExamListView({super.key});

  @override
  Widget build(BuildContext context) {
    var cubit = PackageDetailsCubit.get(context).detailsModel?.data?.exams;
    return ListView.separated(
      physics: const NeverScrollableScrollPhysics(),
      itemBuilder: (context, index) {
        return ExamList(exams: cubit[index], index: index);
      },
      separatorBuilder: (context, index) => Center(
        child: Container(
          height: 0.5,
          width: 330,
          color: Colors.grey.withOpacity(0.4),
        ),
      ),
      itemCount: cubit!.length,
      shrinkWrap: true,
      // scrollDirection: Axis.vertical,
    );
  }
}

// ignore: must_be_immutable
class ExamList extends StatelessWidget {
  Exams? exams;
  final int index;
  ExamList({super.key, this.exams, required this.index});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsetsDirectional.only(start: 10, top: 10),
          child: Row(
            children: [
              CircleAvatar(
                backgroundColor: iconBackgroundColor,
                child: IconButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                ExamOverviewPage(index: index)));
                  },
                  icon: const Icon(
                    Icons.message_outlined,
                    size: 18,
                  ),
                  color: mainColor,
                ),
              ),
              const SizedBox(
                width: 10,
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${exams?.title}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    Text(
                      "${exams?.questionsCount} Questions",
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: smallDescriptionText),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
        const SizedBox(
          height: 24,
        ),
      ],
    );
  }
}

Widget greyLine() => Center(
      child: Container(
        height: 0.5,
        width: 370,
        color: Colors.grey.withOpacity(0.4),
      ),
    );
