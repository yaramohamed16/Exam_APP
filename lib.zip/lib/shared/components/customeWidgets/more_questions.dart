import 'package:exams_app/shared/components/customeWidgets/custom_bottom_sheet.dart';
import 'package:flutter/material.dart';

void showCustomBottomSheet(BuildContext context) {
  showModalBottomSheet(
    context: context,
    builder: (BuildContext context) {
      return Container(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "More ",
                  style: TextStyle(
                    fontSize: 16,
                    color: Color(0xff030712),
                    fontWeight: FontWeight.bold,
                  ),
                ),
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: Image.asset('assets/images/close-circle.png'),
                )
              ],
            ),
            const SizedBox(height: 20),
            GestureDetector(
              onTap: () {
                Navigator.pop(context);
                showQuestions(context, 'review');
              },
              child: Container(
                height: 48,
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  border: Border.all(color: const Color(0xffE5E7EB), width: 1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    Image.asset(
                      "assets/images/document-text.png",
                    ),
                    SizedBox(width: 24),
                    Text("All Questions"),
                  ],
                ),
              ),
            ),
          ],
        ),
      );
    },
  );
}
