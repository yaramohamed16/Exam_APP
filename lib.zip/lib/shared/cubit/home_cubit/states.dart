abstract class ExamsStats {}

class ExamsInitialStats extends ExamsStats {}

class ExamPackagesLoading extends ExamsStats {}

class ExamPackagesSuccess extends ExamsStats {}

class ExamPackagesError extends ExamsStats {}
