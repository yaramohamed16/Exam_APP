//model

class DetailsModel {
  Data? data;
  int? statusCode;

  DetailsModel({this.data, this.statusCode});

  DetailsModel.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
    statusCode = json['status_code'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    data['status_code'] = statusCode;
    return data;
  }
}

class Data {
  int? id;
  String? title;
  int? price;
  String? description;
  String? image;
  int? examsCount;
  int? discountPrice;
  List<Exams>? exams;

  Data({
    this.id,
    this.title,
    this.price,
    this.description,
    this.image,
    this.examsCount,
    this.discountPrice,
    this.exams,
  });

  Data.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title'];
    price = json['price'];
    description = json['description'];
    image = json['image'];
    examsCount = json['exams_count'];
    discountPrice = json['discount_price'];
    if (json['exams'] != null) {
      exams = <Exams>[];
      json['exams'].forEach((v) {
        exams!.add(Exams.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['title'] = title;
    data['price'] = price;
    data['description'] = description;
    data['image'] = image;
    data['exams_count'] = examsCount;
    data['discount_price'] = discountPrice;
    if (exams != null) {
      data['exams'] = exams!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Exams {
  int? id;
  String? title;

  int? questionsCount;

  Exams({
    this.id,
    this.title,
    this.questionsCount,
  });

  Exams.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title'];

    questionsCount = json['questions_count'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['title'] = title;

    data['questions_count'] = questionsCount;

    return data;
  }
}
