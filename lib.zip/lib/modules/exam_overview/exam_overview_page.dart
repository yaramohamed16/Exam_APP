import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../shared/components/constants.dart';
import '../../shared/components/customeWidgets/custome_app_bar.dart';
import '../../shared/components/customeWidgets/custome_bottom_button.dart';
import '../../shared/components/customeWidgets/custome_details_card.dart';
import '../../shared/components/customeWidgets/custome_line.dart';

import '../../shared/cubit/exam_overview_cubit/cubit.dart';
import '../../shared/cubit/exam_overview_cubit/states.dart';

// ignore: must_be_immutable
class ExamOverviewPage extends StatelessWidget {
  final int index;

  const ExamOverviewPage({super.key, required this.index});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => ExamsCubit()..getExamOverview(),
      child: BlocConsumer<ExamsCubit, ExamsOverviewStats>(
        listener: (context, state) {},
        builder: (context, state) {
          var cubit = ExamsCubit.get(context).examOverviewData;
          return Scaffold(
            appBar: cubit?.data!.exams?[index].title != null
                ? appBarCustom(
                    pageName: "${cubit?.data!.title}", context: context)
                : appBarCustom(pageName: "", context: context),
            body: cubit != null
                ? Padding(
                    padding:
                        const EdgeInsetsDirectional.only(start: 24, end: 24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 5),
                        const CustomeLine(),
                        const SizedBox(height: 24),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${cubit.data?.exams?[index].title}',
                              style: const TextStyle(
                                  fontWeight: FontWeight.w600,
                                  color: Color(0xff020939),
                                  fontSize: 20),
                            ),
                            (cubit.data?.exams?[index].description != '')
                                ? const SizedBox(height: 20)
                                : const SizedBox(),
                            Text(
                              '${cubit.data?.exams?[index].description}',
                              style: const TextStyle(
                                  fontWeight: FontWeight.w400,
                                  color: Color(0xff4B5563),
                                  fontSize: 14),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 30,
                        ),
                        Row(
                          children: [
                            CustomeDetailsCard(
                                index: index,
                                title: "Questions",
                                iconName: Icons.description_outlined),
                            const SizedBox(width: 16),
                            CustomeDetailsCard(
                                index: index,
                                title: "Min score",
                                iconName: Icons.gpp_good_outlined),
                          ],
                        ),
                        const Spacer(flex: 1),
                        const Row(children: [
                          Text(
                            " Your grade",
                            style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: Color(0xff020939)),
                          ),
                          Spacer(
                            flex: 1,
                          ),
                          Text("---")
                        ]),
                        CustomeBottomButton(
                            index: index, bottomTitle: "Start Exam")
                      ],
                    ),
                  )
                : Center(
                    child: CircularProgressIndicator(
                      color: mainColor,
                    ),
                  ),
          );
        },
      ),
    );
  }
}
