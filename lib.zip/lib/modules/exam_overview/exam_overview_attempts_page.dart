import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../shared/components/customeWidgets/custome_app_bar.dart';
import '../../shared/components/customeWidgets/custome_attempts_card.dart';
import '../../shared/components/customeWidgets/custome_bottom_button.dart';
import '../../shared/components/customeWidgets/custome_details_card.dart';
import '../../shared/components/customeWidgets/custome_line.dart';
import '../../shared/cubit/exam_overview_cubit/cubit.dart';
import '../../shared/cubit/exam_overview_cubit/states.dart';

// ignore: must_be_immutable
class ExamOverviewAttemptsPage extends StatelessWidget {
  ExamOverviewAttemptsPage({
    super.key,
    required this.index,
    required this.grade,
  });

  String grade;
  final int index;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => ExamsCubit()..getExamOverview(),
      child: BlocConsumer<ExamsCubit, ExamsOverviewStats>(
          listener: (BuildContext context, Object? state) {},
          builder: (BuildContext context, state) {
            var cubit = ExamsCubit.get(context).examOverviewData;
            return Scaffold(
              appBar: cubit?.data!.exams?[index].title != null
                  ? appBarCustom(
                      pageName: "${cubit?.data!.exams?[index].title}",
                      context: context)
                  : appBarCustom(pageName: "", context: context),
              body: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 5),
                  const CustomeLine(),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(25, 15, 90, 0),
                    child: Column(
                      children: [
                        Text(
                          "${cubit?.data?.exams?[0].title}",
                          style: const TextStyle(
                              fontWeight: FontWeight.w600,
                              color: Color(0xff020939),
                              fontSize: 20),
                        ),
                        const SizedBox(height: 20),
                        Text(
                          "${cubit?.data?.exams?[0].description}",
                          style: const TextStyle(
                              fontWeight: FontWeight.w400,
                              color: Color(0xff4B5563),
                              fontSize: 14),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 25),
                        child: CustomeDetailsCard(
                            index: index,
                            title: "Questions",
                            iconName: Icons.description_outlined),
                      ),
                      const SizedBox(width: 50),
                      CustomeDetailsCard(
                        index: index,
                        title: "Min score",
                        iconName: Icons.gpp_good_outlined,
                      ),
                    ],
                  ),
                  Center(
                    child: Container(
                      height: 0.5,
                      width: 350,
                      color: Colors.grey.withOpacity(0.4),
                    ),
                  ),
                  const SizedBox(height: 30),
                  const Padding(
                      padding: EdgeInsets.only(left: 25),
                      child: Text(
                        "Previous Attempts",
                        style: TextStyle(
                            fontSize: 14,
                            color: Color(0xff020939),
                            fontWeight: FontWeight.bold),
                      )),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      child: ListView.separated(
                        itemBuilder: (context, index) =>
                            const CustomeAttemptsCard(),
                        itemCount: 3,
                        scrollDirection: Axis.vertical,
                        separatorBuilder: (context, index) =>
                            const SizedBox(height: 5),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 30),
                    child: Row(children: [
                      Column(children: [
                        const Text(
                          " Your last grade",
                          style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: Color(0xff020939)),
                        ),
                        Text(
                          grade,
                          style: const TextStyle(fontSize: 10),
                        )
                      ]),
                      const Spacer(
                        flex: 1,
                      ),
                      const Text(
                        "80%",
                        style: TextStyle(
                            color: Colors.green,
                            fontSize: 22,
                            fontWeight: FontWeight.w700),
                      ),
                    ]),
                  ),
                  CustomeBottomButton(
                    index: index,
                    bottomTitle: "Start New Attempt",
                  )
                ],
              ),
            );
          }),
    );
  }
}
